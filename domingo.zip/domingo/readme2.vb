Option Explicit

'==============================================================================
'  MÓDULO2 - Actas de asignación / devolución
'  Reemplazo completo: conserva Botón17_Haga_clic_en (botón GUARDAR)
'==============================================================================
Private Const RUTA_HISTORICO As String = "\\172.20.0.22\Unidad_U\DOCUMENTOS\CAMBIO DE EQUIPOS\AUTOMATIZADO\DATA_SYNC\iTopHistorico.xlsx"
Private Const RUTA_PDF As String = "\\172.20.0.22\unidad_u\DOCUMENTOS\CAMBIO DE EQUIPOS\AUTOMATIZADO\ACTAS_FIRMADAS\"

Private mGuardando As Boolean
Private mUltimaActa As String

'------------------------------------------------------------------------------
' BOTÓN EXISTENTE
'------------------------------------------------------------------------------
Public Sub Botón17_Haga_clic_en()
    GuardarActa
End Sub

'------------------------------------------------------------------------------
' BOTONES NUEVOS: agregar filas
'------------------------------------------------------------------------------
Public Sub AgregarFilaAsignacion()
    AgregarFila "Asignación"
End Sub

Public Sub AgregarFilaDevolucion()
    AgregarFila "Devolución"
End Sub

Private Sub AgregarFila(ByVal etiqueta As String)
    Dim ws As Worksheet
    Dim fIni As Long, fFin As Long, fIns As Long

    Set ws = ThisWorkbook.Sheets("Formulario")
    BloqueDatos ws, etiqueta, fIni, fFin, fIns

    If fIni = 0 Then
        MsgBox "No se encontró el bloque """ & etiqueta & """ en el formulario.", vbExclamation
        Exit Sub
    End If

    Application.ScreenUpdating = False

    ' 1) Insertar la fila (todo lo de abajo baja solo)
    ws.Rows(fIns).Insert Shift:=xlDown, CopyOrigin:=xlFormatFromLeftOrAbove

    ' 2) Copiar el formato de la fila de datos anterior
    If fFin >= fIni Then
        ws.Rows(fFin).Copy
        ws.Rows(fIns).PasteSpecial Paste:=xlPasteFormats
        Application.CutCopyMode = False
    End If

    ' 3) La celda de número de serie va combinada A:B, como las demás
    With ws.Range(ws.Cells(fIns, 1), ws.Cells(fIns, 2))
        If Not .MergeCells Then .Merge
    End With

    ' 4) No arrastrar valores de la fila anterior
    ws.Range(ws.Cells(fIns, 1), ws.Cells(fIns, 6)).ClearContents

    ' 5) Fórmulas de búsqueda (las mismas que ya usa el formulario)
    ws.Cells(fIns, 3).Formula = "=IFERROR(INDEX(dataDispositivos!$E$2:$E$2001,MATCH(A" & fIns & ",dataDispositivos!$B$2:$B$2001,0)),"""")"
    ws.Cells(fIns, 4).Formula = "=IFERROR(INDEX(dataDispositivos!$G$2:$G$2001,MATCH(A" & fIns & ",dataDispositivos!$B$2:$B$2001,0)),"""")"
    ws.Cells(fIns, 5).Formula = "=IFERROR(INDEX(dataDispositivos!$C$2:$C$2001,MATCH(A" & fIns & ",dataDispositivos!$B$2:$B$2001,0)),"""")"

    ' 6) El área de impresión crece con el formulario (si no, el PDF se corta)
    ws.PageSetup.PrintArea = "$A$1:$F$" & UltimaFilaImpresion(ws)

    Application.ScreenUpdating = True

    ws.Activate
    ws.Cells(fIns, 1).Select
End Sub

'------------------------------------------------------------------------------
' GUARDAR ACTA - dinámico: no usa rangos fijos (17-23 / 30-36)
'------------------------------------------------------------------------------
Public Sub GuardarActa()
    Dim ws As Worksheet
    Dim wbHist As Workbook, wsActas As Worksheet, wsDet As Worksheet
    Dim aIni As Long, aFin As Long, aIns As Long
    Dim dIni As Long, dFin As Long, dIns As Long
    Dim nroActa As String, fCab As Long, total As Long

    If mGuardando Then Exit Sub          ' evita doble clic

    Set ws = ThisWorkbook.Sheets("Formulario")

    BloqueDatos ws, "Asignación", aIni, aFin, aIns
    BloqueDatos ws, "Devolución", dIni, dFin, dIns

    total = (aFin - aIni + 1) + (dFin - dIni + 1)
    If total <= 0 Then
        MsgBox "No hay equipos cargados en el formulario.", vbExclamation
        Exit Sub
    End If

    If mUltimaActa <> "" Then
        If MsgBox("El acta " & mUltimaActa & " ya fue registrada." & vbCrLf & _
                  "¿Desea generar OTRA acta con los mismos datos?", _
                  vbYesNo + vbQuestion, "Guardar acta") = vbNo Then Exit Sub
    End If

    mGuardando = True
    On Error GoTo ErrGuardar

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Set wbHist = Workbooks.Open(RUTA_HISTORICO)          ' se abre UNA sola vez
    nroActa = GenerarNroActa(wbHist)

    '--- cabecera en el formulario ---
    ws.Range("F4").Value = nroActa
    ws.Range("H4").Value = nroActa

    '--- cabecera en el histórico ---
    Set wsActas = wbHist.Sheets("Actas")
    fCab = wsActas.Cells(wsActas.Rows.Count, 1).End(xlUp).Row + 1
    wsActas.Cells(fCab, 1).Value = nroActa
    wsActas.Cells(fCab, 2).Value = Now
    wsActas.Cells(fCab, 3).Value = ws.Range("C9").Value
    wsActas.Cells(fCab, 4).Value = ws.Range("C10").Value
    wsActas.Cells(fCab, 5).Value = ws.Range("C11").Value
    wsActas.Cells(fCab, 6).Value = ws.Range("C12").Value
    wsActas.Cells(fCab, 7).Value = ws.Range("C13").Value

    '--- detalle dinámico: recorre lo que haya en cada bloque ---
    Set wsDet = wbHist.Sheets("Detalles")
    If aFin >= aIni Then EscribirDetalle wsDet, ws, nroActa, "ASIGNACION", aIni, aFin, TextoObservacion(ws, aFin)
    If dFin >= dIni Then EscribirDetalle wsDet, ws, nroActa, "DEVOLUCION", dIni, dFin, TextoObservacion(ws, dFin)

    wbHist.Save
    wbHist.Close SaveChanges:=False
    Set wbHist = Nothing

    mUltimaActa = nroActa
    mGuardando = False
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "Acta registrada correctamente: " & nroActa, vbInformation

    On Error Resume Next
    GenerarPDF nroActa
    If Err.Number <> 0 Then
        MsgBox "El acta se guardó, pero no se pudo generar el PDF." & vbCrLf & Err.Description, vbExclamation
        Err.Clear
    End If
    On Error GoTo 0
    Exit Sub

ErrGuardar:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    mGuardando = False
    If Not wbHist Is Nothing Then
        On Error Resume Next
        wbHist.Close SaveChanges:=False
        On Error GoTo 0
    End If
    MsgBox "No se pudo guardar el acta." & vbCrLf & vbCrLf & Err.Description, vbCritical
End Sub

'--- escribe las filas de un bloque, saltando las vacías ---
Private Sub EscribirDetalle(wsDet As Worksheet, wsForm As Worksheet, _
                            ByVal nroActa As String, ByVal tipo As String, _
                            ByVal fIni As Long, ByVal fFin As Long, _
                            ByVal observacion As String)
    Dim r As Long, f As Long
    For r = fIni To fFin
        If Trim$(CStr(wsForm.Cells(r, 1).Value)) <> "" Then
            f = wsDet.Cells(wsDet.Rows.Count, 1).End(xlUp).Row + 1
            wsDet.Cells(f, 1).Value = nroActa
            wsDet.Cells(f, 2).Value = tipo
            wsDet.Cells(f, 3).Value = wsForm.Range("H10").Value
            wsDet.Cells(f, 4).Value = wsForm.Cells(r, 1).Value   ' serie
            wsDet.Cells(f, 5).Value = wsForm.Cells(r, 3).Value   ' modelo
            wsDet.Cells(f, 6).Value = wsForm.Cells(r, 4).Value   ' marca
            wsDet.Cells(f, 7).Value = wsForm.Cells(r, 5).Value   ' clase
            wsDet.Cells(f, 8).Value = wsForm.Cells(r, 6).Value   ' estado
            wsDet.Cells(f, 9).Value = observacion
        End If
    Next r
End Sub

'--- número de acta: lo calcula con la última fila real de la hoja Actas ---
Public Function GenerarNroActa(wbHist As Workbook) As String
    Dim ws As Worksheet, r As Long, ult As Long
    Set ws = wbHist.Sheets("Actas")
    ult = 1
    For r = 2 To ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
        If UCase$(Left$(Trim$(CStr(ws.Cells(r, 1).Value))), 6) = "ASIGDEV" Then ult = r
    Next r
    GenerarNroActa = "ASIGDEV" & Format$(Date, "yyyy") & "-" & Format$(ult, "000")
End Function

Public Sub GenerarPDF(ByVal nroActa As String)
    ThisWorkbook.Sheets("Formulario").ExportAsFixedFormat _
        Type:=0, _
        Filename:=RUTA_PDF & nroActa & ".pdf", _
        Quality:=0, _
        IncludeDocProperties:=True, _
        IgnorePrintAreas:=False, _
        OpenAfterPublish:=True
End Sub

'==============================================================================
'  AUXILIARES DE BLOQUE  (nada de filas fijas)
'==============================================================================
Private Sub BloqueDatos(ws As Worksheet, ByVal etiqueta As String, _
                        ByRef fIni As Long, ByRef fFin As Long, ByRef fIns As Long)
    Dim fEt As Long, fObs As Long, fOtra As Long

    fIni = 0: fFin = -1: fIns = 0

    fEt = PrimeraFilaEtiqueta(ws, etiqueta)
    If fEt = 0 Then Exit Sub

    fIni = fEt + 2                      ' etiqueta + fila de encabezados

    ' Límite del bloque: la celda combinada A:F con las observaciones
    fObs = FilaObservacion(ws, fIni)

    ' Respaldo por si las observaciones estuvieran sin combinar
    If fObs = 0 Then
        fOtra = PrimeraFilaEtiqueta(ws, NombreContrario(etiqueta))
        If fOtra > fIni Then fObs = fOtra
    End If
    If fObs = 0 Then fObs = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1

    ' Última fila con número de serie antes de las observaciones
    fFin = fObs - 1
    Do While fFin >= fIni
        If Trim$(CStr(ws.Cells(fFin, 1).Value)) <> "" Then Exit Do
        fFin = fFin - 1
    Loop
    If fFin < fIni Then fFin = fIni - 1     ' bloque vacío

    fIns = fFin + 1                         ' ahí se inserta la fila nueva
End Sub

' Primera fila de la columna A cuyo texto EMPIEZA con la etiqueta
' (compara los primeros 8 caracteres en mayúsculas: ASIGNACI / DEVOLUCI,
'  así no depende de acentos ni de cómo se guarde el texto)
Private Function PrimeraFilaEtiqueta(ws As Worksheet, ByVal etiqueta As String) As Long
    Dim r As Long, ult As Long, v As String, clave As String
    clave = UCase$(Left$(etiqueta, 8))
    ult = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 1 To ult
        v = UCase$(Trim$(CStr(ws.Cells(r, 1).Value)))
        If Len(v) >= 8 Then
            If Left$(v, 8) = clave Then
                PrimeraFilaEtiqueta = r
                Exit Function
            End If
        End If
    Next r
End Function

' Fila de la observación: celda combinada A:F (6 columnas o más)
Private Function FilaObservacion(ws As Worksheet, ByVal fDesde As Long) As Long
    Dim r As Long, ult As Long
    ult = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = fDesde To ult
        If ws.Cells(r, 1).MergeCells Then
            If ws.Cells(r, 1).MergeArea.Columns.Count >= 6 Then
                FilaObservacion = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Function NombreContrario(ByVal etiqueta As String) As String
    If UCase$(Left$(etiqueta, 8)) = "ASIGNACI" Then
        NombreContrario = "Devolución"
    Else
        NombreContrario = "Asignación"
    End If
End Function

' Texto de observaciones del bloque (fila vacía opcional + celda combinada)
Private Function TextoObservacion(ws As Worksheet, ByVal fFin As Long) As String
    Dim r As Long, v As String
    r = fFin + 1
    Do While r <= fFin + 4
        v = Trim$(CStr(ws.Cells(r, 1).Value))
        If v <> "" Then
            TextoObservacion = v
            Exit Function
        End If
        r = r + 1
    Loop
End Function

' Última fila a imprimir: incluye la fila combinada de la cláusula + 1
Private Function UltimaFilaImpresion(ws As Worksheet) As Long
    Dim r As Long
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If ws.Cells(r, 1).MergeCells Then
        r = ws.Cells(r, 1).MergeArea.Row + ws.Cells(r, 1).MergeArea.Rows.Count - 1
    End If
    UltimaFilaImpresion = r + 1
End Function