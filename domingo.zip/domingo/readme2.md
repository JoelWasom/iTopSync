quiero que mejores el formulario, necestio crear 2 botones: para agregar mas filas de asignaciones y devoluciones. y en el vba el guardar acta debe ser dynamico.
+Thought · 3m 38s
Voy a inspeccionar cómo están construidos los botones actuales y qué herramientas tengo disponibles para editar el .xlsm.
→Explored: 1 read
$ $x="C:\Users\asus\AppData\Local\Temp\opencode\asigdev002\x"
"=== VML buttons (raw, from shape 1041 onward) ==="…
(55 earlier lines)



=== AccessVBOM ===
=== COM available? ===
Excel.Application PROGID OK
+Thought · 2m 11s
Ya tengo el mapa completo. Hallazgos clave para esta tarea:
- Excel 2021 (x64) está instalado en la máquina → puedo editar vía COM.
- Los botones actuales son controles de formulario en vmlDrawing1.vml (caption + FmlaMacro → Botón17_Haga_clic_en), con su réplica oculta en drawing1.xml.
- "Acceso al objeto modelo de VBA" (AccessVBOM) está desactivado → sin eso, Excel no me deja escribir código VBA por COM.
- El archivo abre con Workbook_Open que intenta sincronizar por red (\\172.20.0.22); en la verificación lo abriré con macros desactivadas para que no dispare esa sincronización.
Diseño previsto (lo asumo salvo que me digas lo contrario): cada botón inserta 1 fila al final de su bloque (los bloques quedan en filas 17-23 y 30-36 hoy; al insertar, el bloque de devolución y las firmas bajan solos, y el área de impresión se amplía automáticamente), y GuardarActa deja de usar rangos fijos y recorre las filas mientras la columna A tenga número de serie, tomando el texto de observación de cada bloque dinámicamente.
Antes de tocar el archivo necesito que decidas cómo edito el VBA:
# Questions
¿Cómo prefieres que escriba el código VBA nuevo en el archivo?
Solo me entregas el código
+Thought · 12m 38s
Perfecto: no toco el archivo. Te entrego el VBA listo para pegar y los pasos exactos para crear los dos botones.
Guardo la decisión en memoria y va el código.
✓execute
›engram.mem_save [title=ASIGDEV: usuario eligió recibir solo código VBA + instrucciones (no editar el xlsm), type=decision, scope=project, topic_key=asigdev/asignacion-devolucion-workbook, capture_prompt=false, content=What: Para la mejora de ASIGDEV2026-002.xlsm el usuario eligió la opción 'solo me entregas el código': NO debo modificar el archivo; entrego el VBA listo para pegar y las instrucciones para crear 2 botones (agregar fila de asignación y de devolución) y GuardarActa dinámico. Why: Prefiere aplicarlo él en Excel; AccessVBOM está desactivado en HKCU (Office 2021 Volume x64, Excel en C:\Program Files\Microsoft Office\root\Office16\), por lo que COM no puede escribir VBA sin cambiar esa clave de seguridad. Where: D:\Proyectos\DATA_ANDINA\ASIGDEV2026-002.xlsm. VBA entregado para reemplazar todo Módulo2 (conserva Botón17_Haga_clic_en) y opcionalmente Módulo3 (Botón18 con validación). Learned: Diseño dinámico: BloqueDatos localiza la etiqueta (match por prefijo 8 chars 'ASIGNACI'/'DEVOLUCI', sin acentos), fIni=etiqueta+2, límite = celda combinada A:F de observaciones (>=6 columnas), fFin = última fila no vacía antes de esa observación, fIns=fFin+1. El botón inserta fila, copia formatos, mergea A:B, limpia A:F, reescribe las 3 fórmulas INDEX/MATCH y amplía PageSetup.PrintArea a '$A$1:$F$' & última fila +1. GuardarActa recorre los bloques dinámicamente, GenerarNroActa recibe el wbHist (evita abrir 2 veces) y busca la última fila que empiece con ASIGDEV. Límite conocido no corregido: fórmulas $2:$2001 vs 4982 dispositivos (ofrecido como mejora opcional).]
+Thought · 1m 20s
1. Reemplaza TODO el módulo Módulo2
Alt+F11 → VBAProject → Módulo2 → Ctrl+A → pega este bloque completo (borra primero lo que haya):
Option Explicit

'==============================================================================
'  MÓDULO2 - Actas de asignación / devolución
'  Reemplazo completo: conserva Botón17_Haga_clic_en (botón GUARDAR)
'==============================================================================
Private Const RUTA_HISTORICO As String = "\\172.20.0.22\Unidad_U\DOCUMENTOS\CAMBIO DE EQUIPOS\AUTOMATIZADO\DATA_SYNC\iTopHistorico.xlsx"
Private Const RUTA_PDF As String = "\\172.20.0.22\unidad_u\DOCUMENTOS\CAMBIO DE EQUIPOS\AUTOMATIZADO\ACTAS_FIRMADAS\"

Private mGuardando As Boolean
Private mUltimaActa As String

'------------------------------------------------------------------------------
' BOTÓN EXISTENTE
'------------------------------------------------------------------------------
Public Sub Botón17_Haga_clic_en()
    GuardarActa
End Sub

'------------------------------------------------------------------------------
' BOTONES NUEVOS: agregar filas
'------------------------------------------------------------------------------
Public Sub AgregarFilaAsignacion()
    AgregarFila "Asignación"
End Sub

Public Sub AgregarFilaDevolucion()
    AgregarFila "Devolución"
End Sub

Private Sub AgregarFila(ByVal etiqueta As String)
    Dim ws As Worksheet
    Dim fIni As Long, fFin As Long, fIns As Long

    Set ws = ThisWorkbook.Sheets("Formulario")
    BloqueDatos ws, etiqueta, fIni, fFin, fIns

    If fIni = 0 Then
        MsgBox "No se encontró el bloque """ & etiqueta & """ en el formulario.", vbExclamation
        Exit Sub
    End If

    Application.ScreenUpdating = False

    ' 1) Insertar la fila (todo lo de abajo baja solo)
    ws.Rows(fIns).Insert Shift:=xlDown, CopyOrigin:=xlFormatFromLeftOrAbove

    ' 2) Copiar el formato de la fila de datos anterior
    If fFin >= fIni Then
        ws.Rows(fFin).Copy
        ws.Rows(fIns).PasteSpecial Paste:=xlPasteFormats
        Application.CutCopyMode = False
    End If

    ' 3) La celda de número de serie va combinada A:B, como las demás
    With ws.Range(ws.Cells(fIns, 1), ws.Cells(fIns, 2))
        If Not .MergeCells Then .Merge
    End With

    ' 4) No arrastrar valores de la fila anterior
    ws.Range(ws.Cells(fIns, 1), ws.Cells(fIns, 6)).ClearContents

    ' 5) Fórmulas de búsqueda (las mismas que ya usa el formulario)
    ws.Cells(fIns, 3).Formula = "=IFERROR(INDEX(dataDispositivos!$E$2:$E$2001,MATCH(A" & fIns & ",dataDispositivos!$B$2:$B$2001,0)),"""")"
    ws.Cells(fIns, 4).Formula = "=IFERROR(INDEX(dataDispositivos!$G$2:$G$2001,MATCH(A" & fIns & ",dataDispositivos!$B$2:$B$2001,0)),"""")"
    ws.Cells(fIns, 5).Formula = "=IFERROR(INDEX(dataDispositivos!$C$2:$C$2001,MATCH(A" & fIns & ",dataDispositivos!$B$2:$B$2001,0)),"""")"

    ' 6) El área de impresión crece con el formulario (si no, el PDF se corta)
    ws.PageSetup.PrintArea = "$A$1:$F$" & UltimaFilaImpresion(ws)

    Application.ScreenUpdating = True

    ws.Activate
    ws.Cells(fIns, 1).Select
End Sub

'------------------------------------------------------------------------------
' GUARDAR ACTA - dinámico: no usa rangos fijos (17-23 / 30-36)
'------------------------------------------------------------------------------
Public Sub GuardarActa()
    Dim ws As Worksheet
    Dim wbHist As Workbook, wsActas As Worksheet, wsDet As Worksheet
    Dim aIni As Long, aFin As Long, aIns As Long
    Dim dIni As Long, dFin As Long, dIns As Long
    Dim nroActa As String, fCab As Long, total As Long

    If mGuardando Then Exit Sub          ' evita doble clic

    Set ws = ThisWorkbook.Sheets("Formulario")

    BloqueDatos ws, "Asignación", aIni, aFin, aIns
    BloqueDatos ws, "Devolución", dIni, dFin, dIns

    total = (aFin - aIni + 1) + (dFin - dIni + 1)
    If total <= 0 Then
        MsgBox "No hay equipos cargados en el formulario.", vbExclamation
        Exit Sub
    End If

    If mUltimaActa <> "" Then
        If MsgBox("El acta " & mUltimaActa & " ya fue registrada." & vbCrLf & _
                  "¿Desea generar OTRA acta con los mismos datos?", _
                  vbYesNo + vbQuestion, "Guardar acta") = vbNo Then Exit Sub
    End If

    mGuardando = True
    On Error GoTo ErrGuardar

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Set wbHist = Workbooks.Open(RUTA_HISTORICO)          ' se abre UNA sola vez
    nroActa = GenerarNroActa(wbHist)

    '--- cabecera en el formulario ---
    ws.Range("F4").Value = nroActa
    ws.Range("H4").Value = nroActa

    '--- cabecera en el histórico ---
    Set wsActas = wbHist.Sheets("Actas")
    fCab = wsActas.Cells(wsActas.Rows.Count, 1).End(xlUp).Row + 1
    wsActas.Cells(fCab, 1).Value = nroActa
    wsActas.Cells(fCab, 2).Value = Now
    wsActas.Cells(fCab, 3).Value = ws.Range("C9").Value
    wsActas.Cells(fCab, 4).Value = ws.Range("C10").Value
    wsActas.Cells(fCab, 5).Value = ws.Range("C11").Value
    wsActas.Cells(fCab, 6).Value = ws.Range("C12").Value
    wsActas.Cells(fCab, 7).Value = ws.Range("C13").Value

    '--- detalle dinámico: recorre lo que haya en cada bloque ---
    Set wsDet = wbHist.Sheets("Detalles")
    If aFin >= aIni Then EscribirDetalle wsDet, ws, nroActa, "ASIGNACION", aIni, aFin, TextoObservacion(ws, aFin)
    If dFin >= dIni Then EscribirDetalle wsDet, ws, nroActa, "DEVOLUCION", dIni, dFin, TextoObservacion(ws, dFin)

    wbHist.Save
    wbHist.Close SaveChanges:=False
    Set wbHist = Nothing

    mUltimaActa = nroActa
    mGuardando = False
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "Acta registrada correctamente: " & nroActa, vbInformation

    On Error Resume Next
    GenerarPDF nroActa
    If Err.Number <> 0 Then
        MsgBox "El acta se guardó, pero no se pudo generar el PDF." & vbCrLf & Err.Description, vbExclamation
        Err.Clear
    End If
    On Error GoTo 0
    Exit Sub

ErrGuardar:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    mGuardando = False
    If Not wbHist Is Nothing Then
        On Error Resume Next
        wbHist.Close SaveChanges:=False
        On Error GoTo 0
    End If
    MsgBox "No se pudo guardar el acta." & vbCrLf & vbCrLf & Err.Description, vbCritical
End Sub

'--- escribe las filas de un bloque, saltando las vacías ---
Private Sub EscribirDetalle(wsDet As Worksheet, wsForm As Worksheet, _
                            ByVal nroActa As String, ByVal tipo As String, _
                            ByVal fIni As Long, ByVal fFin As Long, _
                            ByVal observacion As String)
    Dim r As Long, f As Long
    For r = fIni To fFin
        If Trim$(CStr(wsForm.Cells(r, 1).Value)) <> "" Then
            f = wsDet.Cells(wsDet.Rows.Count, 1).End(xlUp).Row + 1
            wsDet.Cells(f, 1).Value = nroActa
            wsDet.Cells(f, 2).Value = tipo
            wsDet.Cells(f, 3).Value = wsForm.Range("H10").Value
            wsDet.Cells(f, 4).Value = wsForm.Cells(r, 1).Value   ' serie
            wsDet.Cells(f, 5).Value = wsForm.Cells(r, 3).Value   ' modelo
            wsDet.Cells(f, 6).Value = wsForm.Cells(r, 4).Value   ' marca
            wsDet.Cells(f, 7).Value = wsForm.Cells(r, 5).Value   ' clase
            wsDet.Cells(f, 8).Value = wsForm.Cells(r, 6).Value   ' estado
            wsDet.Cells(f, 9).Value = observacion
        End If
    Next r
End Sub

'--- número de acta: lo calcula con la última fila real de la hoja Actas ---
Public Function GenerarNroActa(wbHist As Workbook) As String
    Dim ws As Worksheet, r As Long, ult As Long
    Set ws = wbHist.Sheets("Actas")
    ult = 1
    For r = 2 To ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
        If UCase$(Left$(Trim$(CStr(ws.Cells(r, 1).Value))), 6) = "ASIGDEV" Then ult = r
    Next r
    GenerarNroActa = "ASIGDEV" & Format$(Date, "yyyy") & "-" & Format$(ult, "000")
End Function

Public Sub GenerarPDF(ByVal nroActa As String)
    ThisWorkbook.Sheets("Formulario").ExportAsFixedFormat _
        Type:=0, _
        Filename:=RUTA_PDF & nroActa & ".pdf", _
        Quality:=0, _
        IncludeDocProperties:=True, _
        IgnorePrintAreas:=False, _
        OpenAfterPublish:=True
End Sub

'==============================================================================
'  AUXILIARES DE BLOQUE  (nada de filas fijas)
'==============================================================================
Private Sub BloqueDatos(ws As Worksheet, ByVal etiqueta As String, _
                        ByRef fIni As Long, ByRef fFin As Long, ByRef fIns As Long)
    Dim fEt As Long, fObs As Long, fOtra As Long

    fIni = 0: fFin = -1: fIns = 0

    fEt = PrimeraFilaEtiqueta(ws, etiqueta)
    If fEt = 0 Then Exit Sub

    fIni = fEt + 2                      ' etiqueta + fila de encabezados

    ' Límite del bloque: la celda combinada A:F con las observaciones
    fObs = FilaObservacion(ws, fIni)

    ' Respaldo por si las observaciones estuvieran sin combinar
    If fObs = 0 Then
        fOtra = PrimeraFilaEtiqueta(ws, NombreContrario(etiqueta))
        If fOtra > fIni Then fObs = fOtra
    End If
    If fObs = 0 Then fObs = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1

    ' Última fila con número de serie antes de las observaciones
    fFin = fObs - 1
    Do While fFin >= fIni
        If Trim$(CStr(ws.Cells(fFin, 1).Value)) <> "" Then Exit Do
        fFin = fFin - 1
    Loop
    If fFin < fIni Then fFin = fIni - 1     ' bloque vacío

    fIns = fFin + 1                         ' ahí se inserta la fila nueva
End Sub

' Primera fila de la columna A cuyo texto EMPIEZA con la etiqueta
' (compara los primeros 8 caracteres en mayúsculas: ASIGNACI / DEVOLUCI,
'  así no depende de acentos ni de cómo se guarde el texto)
Private Function PrimeraFilaEtiqueta(ws As Worksheet, ByVal etiqueta As String) As Long
    Dim r As Long, ult As Long, v As String, clave As String
    clave = UCase$(Left$(etiqueta, 8))
    ult = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 1 To ult
        v = UCase$(Trim$(CStr(ws.Cells(r, 1).Value)))
        If Len(v) >= 8 Then
            If Left$(v, 8) = clave Then
                PrimeraFilaEtiqueta = r
                Exit Function
            End If
        End If
    Next r
End Function

' Fila de la observación: celda combinada A:F (6 columnas o más)
Private Function FilaObservacion(ws As Worksheet, ByVal fDesde As Long) As Long
    Dim r As Long, ult As Long
    ult = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = fDesde To ult
        If ws.Cells(r, 1).MergeCells Then
            If ws.Cells(r, 1).MergeArea.Columns.Count >= 6 Then
                FilaObservacion = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Function NombreContrario(ByVal etiqueta As String) As String
    If UCase$(Left$(etiqueta, 8)) = "ASIGNACI" Then
        NombreContrario = "Devolución"
    Else
        NombreContrario = "Asignación"
    End If
End Function

' Texto de observaciones del bloque (fila vacía opcional + celda combinada)
Private Function TextoObservacion(ws As Worksheet, ByVal fFin As Long) As String
    Dim r As Long, v As String
    r = fFin + 1
    Do While r <= fFin + 4
        v = Trim$(CStr(ws.Cells(r, 1).Value))
        If v <> "" Then
            TextoObservacion = v
            Exit Function
        End If
        r = r + 1
    Loop
End Function

' Última fila a imprimir: incluye la fila combinada de la cláusula + 1
Private Function UltimaFilaImpresion(ws As Worksheet) As Long
    Dim r As Long
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If ws.Cells(r, 1).MergeCells Then
        r = ws.Cells(r, 1).MergeArea.Row + ws.Cells(r, 1).MergeArea.Rows.Count - 1
    End If
    UltimaFilaImpresion = r + 1
End Function
2. Compila antes de seguir
En el VBE: Depurar → Compilar VBAProject. Tiene que terminar sin errores. Luego Ctrl+S (sigue en .xlsm).
3. Crea los 2 botones
1. Pestaña Desarrollador → Insertar → Botón (control de formulario).
(Si no aparece: Archivo → Opciones → Personalizar cinta de opciones → casilla Desarrollador.)
2. Dibuja el primero en G16 (columna G, al lado del encabezado de Asignación). Queda fuera del área de impresión A1:F50, así que no sale en el PDF.
3. En el cuadro de asignación de macro escribe: AgregarFilaAsignacion → texto del botón: + FILA ASIGNACIÓN.
4. Segundo botón en G29 (al lado de Devolución) → macro AgregarFilaDevolucion → texto: + FILA DEVOLUCIÓN.
5. Clic derecho → Formato de control → Propiedades → "Mover pero no cambiar tamaño con celdas". Así cada botón sigue a su bloque cuando el otro crece.
4. Qué cambia
Antes	Ahora
Asignaciones fijas 17–23, devoluciones 30–36	BloqueDatos localiza etiqueta → encabezados → última fila con serie, límite = la celda combinada A:F de observaciones
Botón inserta fila "a ciegas"	Inserta en fFin+1, copia formato, combina A:B, limpia A:F, reescribe las 3 fórmulas y amplía el área de impresión (si no, el PDF se corta)
GuardarActa escribía filas fijas → perdía filas nuevas	Recorre cada bloque y salta vacías; observaciones tomadas dinámicamente
GenerarNroActa abría el histórico dos veces	Se abre una sola vez y se pasa el libro; además ignora filas basura buscando lo que empiece por ASIGDEV
Doble clic = registro repetido	mGuardando bloquea durante el guardado + confirmación si repites la misma acta
5. Pruébalo así
1. + FILA ASIGNACIÓN → aparece una fila vacía con A:B combinado, MODELO/MARCA/CLASE en blanco y el área de impresión creció.
2. Escribe un número de serie → se completan solos.
3. GUARDAR Y GENERAR PDF → genera el número, registra cabecera + todas las filas de ambos bloques en iTopHistorico.xlsx (hojas Actas y Detalles) y exporta el PDF.
4. Verifica que el PDF llega hasta la cláusula de responsabilidad y las firmas.
Regla para tus usuarios: no inserten filas a mano (se pierden la combinación A:B y el área de impresión); siempre con los botones. Y no dejes filas en blanco dentro de un bloque, o lo que haya debajo no se guardará.
Dos avisos honestos:
- No pude compilarlo yo (AccessVBOM está apagado y elegiste no tocarlo). El paso 2 es obligatorio: si algo no compila, dímelo con el mensaje exacto y lo corrijo.
- Sigue vigente el límite $2:$2001 en las fórmulas de búsqueda, con 4.982 dispositivos cargados: más de la mitad de las series no resuelve. Es un 2001 → 6000 en el módulo y en las fórmulas del formulario. ¿Lo cambio en esta misma entrega?