﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;
using ITOP.Sync.Applicaction.Models;
using ITOP.Sync.Console.Workers;
using ITOP.Sync.Infrastructure.Logging;
using ITOP.Sync.Infrastructure.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ITOP.Sync.Console
{
    internal class Program
    {
        private static async Task Main(string[] args)
        {
            try
            {
                IHost host = Host.CreateDefaultBuilder(args)
                    .ConfigureServices((context, services) =>
                    {
                        services.Configure<ItopConfig>(context.Configuration.GetSection("ItopApi"));

                        services.AddHttpClient<IItopApiService, ItopApiService>();

                        services.AddSingleton<ILoggerService, LoggerService>();
                        services.AddSingleton(new ActiveDirectoryService("ypfb-andina.com.bo"));
                        services.AddSingleton<SyncCache>();

                        services.AddTransient<IModeloService, ModeloService>();
                        services.AddTransient<IDispositivoFisicoService, DispositivoFisicoService>();
                        services.AddTransient<IPerifericoService, PerifericoService>();
                        services.AddTransient<IPersonaService, PersonaService>();
                        services.AddTransient<SyncWorker>();
                        services.AddTransient<ISyncDataLoader, SyncDataLoader>();

                        services.AddScoped<IExcelReaderService,  ExcelReaderService>();
                        services.AddScoped<IExcelWriterService,  ExcelWriterService>();

                    }).Build();

                var worker = host.Services.GetRequiredService<SyncWorker>();
                await worker.ExecuteAsync();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine($"ERROR: {ex.Message}");
                System.Console.WriteLine(ex.StackTrace);
            }
        }
    }
}
