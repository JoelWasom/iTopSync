﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;
using ITOP.Sync.Applicaction.Models;
using ITOP.Sync.Infrastructure.Services;
using Microsoft.Extensions.Configuration;

namespace ITOP.Sync.Console.Workers
{
    public class SyncWorker
    {
        private readonly IConfiguration _configuration;
        private readonly IModeloService _modeloService;
        private readonly ActiveDirectoryService _adService;
        private readonly ILoggerService _logger;
        private readonly IDispositivoFisicoService _dispositivoFisico;
        private readonly ISyncDataLoader _loader;
        private readonly SyncCache _cache;
        private readonly IExcelReaderService _excelReaderService;
        private readonly IExcelWriterService _excelWriterService;
        private readonly IPersonaService _personaService;
        public SyncWorker(
            IConfiguration configuration,
        IModeloService modeloService,
        ActiveDirectoryService adService,
        ILoggerService logger,
        IDispositivoFisicoService dispositivoFisico,
        ISyncDataLoader loader,
        SyncCache cache,
        IExcelReaderService excelReaderService,
        IExcelWriterService excelWriterService,
        IPersonaService personaService)
        {
            _configuration = configuration;
            _modeloService = modeloService;
            _adService = adService;
            _logger = logger;
            _dispositivoFisico = dispositivoFisico;
            _loader = loader;
            _cache = cache;
            _excelReaderService = excelReaderService;
            _excelWriterService = excelWriterService;
            _personaService = personaService;
        }
        public async Task ExecuteAsync()
        {
            try
            {
                EscribirBitacora("Inicio de sincronización ITOP.Sync.2026");
                await VerificarConexionActiveDirectory();
                await VerificarConexionItop();
                await SincronizarArchivoExcelHistoricoAsignaciones();
                await CargarDatosItopEnCache();
                await ActualizarDatosExcelPersona();
                await ActualizarDatosExcelDispositivos();

                EscribirBitacora("Fin de sincronización ITOP.Sync.2026");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error durante sincronización ITOP.Sync.2026");
            }
        }
        private async Task VerificarConexionActiveDirectory()
        {
            const string servicio = "Active Directory";
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            EscribirBitacora($"Iniciando verificación de conexión con {servicio}");
            try
            {
                var result = _adService.ActiveDirectoryDisponible();
                stopwatch.Stop();
                if (result)
                {
                    System.Console.WriteLine($"===== {servicio} =====");
                    EscribirBitacora($"Conexión con {servicio} exitosa.. Tiempo: {stopwatch.ElapsedMilliseconds} ms");                    
                    System.Console.WriteLine("====================");
                }
                else
                {
                    System.Console.WriteLine($"===== {servicio} =====");
                    _logger.LogError($"Error al verificar la conexión con {servicio}. Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                    System.Console.WriteLine("Estado: Error de conexión");
                    System.Console.WriteLine("====================");
                }
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"Error al verificar la conexión con {servicio}. Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine($"===== {servicio} =====");
                System.Console.WriteLine("Estado: Error de conexión por excepción");
                System.Console.WriteLine("====================");
            }
        }
        private async Task VerificarConexionItop()
        {
            const string servicio = "API ITOP";
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            EscribirBitacora($"Iniciando verificación de conexión con {servicio}");
            try
            {
                var modelos = await _modeloService.GetModelosAsync();
                stopwatch.Stop();
                System.Console.WriteLine($"===== {servicio} =====");
                EscribirBitacora($"Conexión con {servicio} exitosa. Tiempo: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine("====================");
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"Error al verificar la conexión con {servicio}. Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine($"===== {servicio} =====");
                System.Console.WriteLine("Estado: Error de conexión o consulta");
                System.Console.WriteLine("====================");
            }
        }
        private async Task CargarDatosItopEnCache()
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            EscribirBitacora("Se inicia la ejecución de consultas a la API iTop para cargar datos en Caché..");
            try
            {
                var loadedCache = await _loader.LoadAsync();
                _cache.Modelos = loadedCache.Modelos;
                _cache.DispositivosPorId = loadedCache.DispositivosPorId;
                _cache.DispositivosPorSerial = loadedCache.DispositivosPorSerial;
                _cache.Personas = loadedCache.Personas;
                _cache.Contactos = loadedCache.Contactos;
                stopwatch.Stop();
                EscribirBitacora($"Datos iTop cargado correctamente en Caché. Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"No se pudo cargar los Datos iTop en Caché. Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine("Estado: No se pudo cargar los Datos iTop en Caché");
            }

        }
        private async Task SincronizarArchivoExcelHistoricoAsignaciones()
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var rutaExcel = _configuration["ExcelSettings:ArchivoHistoricoAsignaciones"];
            EscribirBitacora($"Inicio de Sincronización [ASIGNACIONES] del archivo excel en: {rutaExcel}");
            try
            {
                var registros = await _excelReaderService.LeerArchivo(@$"{rutaExcel}");
                //var agrupados = await _excelReaderService.AgruparDatosExcel(registros);

                stopwatch.Stop();
                


            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"No se pudo cargar los Datos iTop en Caché. Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine("Estado: No se pudo cargar los Datos iTop en Caché");
            }

        }
        private async Task ActualizarDatosExcelPersona()
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var rutaExcel = _configuration["ExcelSettings:ArchivoDatos"];
            EscribirBitacora($"Inicio de Actualización de datos [Persona] en el archivo excel: {rutaExcel}");
            try
            {
                _excelWriterService.GenerarListaPersonasEnExcel(@$"{rutaExcel}", _cache.Personas.Values.ToList(), _cache.Contactos.Values.ToList());
                stopwatch.Stop();
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"No se pudo actualizar los datos de [Persona] en el documento Excel: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine("No se pudo actualizar los datos de [Persona] en el documento Excel");
            }
        }
        private async Task ActualizarDatosExcelDispositivos()
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var rutaExcel = _configuration["ExcelSettings:ArchivoDatos"];
            EscribirBitacora($"Inicio de Actualización de datos [Dispositivos] en el archivo excel: {rutaExcel}");
            try
            {
                _excelWriterService.GenerarListaDispositivosEnExcel(@$"{rutaExcel}", _cache.DispositivosPorSerial.Values.ToList());
                stopwatch.Stop();
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"No se pudo actualizar los datos de [Dispositivos] en el documento Excel: {stopwatch.ElapsedMilliseconds} ms");
                System.Console.WriteLine("No se pudo actualizar los datos de [Dispositivos] en el documento Excel");
            }
        }

        private void EscribirBitacora(string texto)
        {
            System.Console.WriteLine($"{texto}");
            _logger.LogInformation($"{texto}");
        }

        public async Task TestUpdate()
        {
            try
            {
                _logger.LogInformation("Inicio de TEST-Update");
                System.Console.WriteLine("------------------------------------------------");

                var result = await _dispositivoFisico.UpdateDispositivoStatusAsync();
                System.Console.WriteLine(result.ToString());

                System.Console.WriteLine("------------------------------------------------");

                _logger.LogInformation("Proceso finalizado correctamente TEST-Update");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error durante la ejecución del proceso TEST-Update");
                throw;
            }
        }
    }
}