﻿using System.Text.Json.Serialization;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class DispositivoFisicoDto
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("serialnumber")]
        public string NumeroSerial { get; set; }

        [JsonPropertyName("name")]
        public string CodigoEtiqueta { get; set; }

        [JsonPropertyName("status")]
        public string Estado { get; set; }

        [JsonPropertyName("finalclass")]
        public string Clase { get; set; }

        [JsonPropertyName("location_id")]
        public string LocalizacionId { get; set; }

        [JsonPropertyName("pdasigned_id")]
        public string AsignadoId { get; set; }

        [JsonPropertyName("model_id")]
        public string ModeloId { get; set; }

        [JsonPropertyName("model_name")]
        public string Modelo { get; set; }

        [JsonPropertyName("brand_id")]
        public string MarcaId { get; set; }

        [JsonPropertyName("brand_name")]
        public string Marca { get; set; }

        [JsonPropertyName("pdcan")]
        public string Cantidad { get; set; }

        [JsonPropertyName("pddescripcion")]
        public string Descripcion { get; set; }

        [JsonPropertyName("description")]
        public string Observaciones { get; set; }
    }
}
