﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class ExcelConsolidadoDto
    {
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string TipoProducto { get; set; }
        public int Cantidad { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Descripcion { get; set; }
        public string Serial { get; set; }
        public string Codigo { get; set; }
        public string Clase { get; set; }
        public string Observacion { get; set; }
    }
}