﻿
using System.Text.Json.Serialization;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class ModeloDto
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("name")]
        public string Nombre { get; set; }

        [JsonPropertyName("type")]
        public string Tipo { get; set; }

        [JsonPropertyName("brand_id")]
        public string MarcaId { get; set; }

        [JsonPropertyName("brand_name")]
        public string Marca {  get; set; }     
    }
}
