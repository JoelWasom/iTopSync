﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class LocalizacionDto
    {
        public long Id { get; set; }
        public string Nombre { get; set; }
    }
}
