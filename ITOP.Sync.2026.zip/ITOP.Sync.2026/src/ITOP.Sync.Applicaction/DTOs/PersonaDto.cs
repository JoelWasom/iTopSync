﻿
using System.Text.Json.Serialization;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class PersonaDto
    {
        [JsonPropertyName("contactid")]
        public string Id { get; set; }

        [JsonPropertyName("first_name")]
        public string Nombres { get; set; }

        [JsonPropertyName("last_name")]
        public string Apellidos { get; set; }

        public string NombreCompleto { get; set; }

        [JsonPropertyName("login")]
        public string Usuario { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("function")]
        public string CargoFuncional { get; set; }
    }
}
