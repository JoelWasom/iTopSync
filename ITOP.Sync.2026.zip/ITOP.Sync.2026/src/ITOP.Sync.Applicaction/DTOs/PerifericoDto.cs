﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class PerifericoDto
    {
        [JsonPropertyName("key")]
        public string Id { get; set; }

        [JsonPropertyName("pertype")]
        public string Tipo { get; set; }

        [JsonPropertyName("pddescription")]
        public string Descripcion { get; set; }
    }
}
