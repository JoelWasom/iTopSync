﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs.Reportes
{
    public class ListaInventarioGeneralDto
    {
        public string Serial { get; set; }
        public string Codigo { get; set; }
        public string TipoProducto { get; set; }
        public string Item { get; set; }
        public int Cantidad { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }
        public string Localidad { get; set; }
        public string Cuenta { get; set; }
        public string NombreCompleto { get; set; }
        public string Email { get; set; }
        public string Observaciones { get; set; }
    }
}
