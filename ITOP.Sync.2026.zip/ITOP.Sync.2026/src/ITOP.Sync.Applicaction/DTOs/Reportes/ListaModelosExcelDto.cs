﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs.Reportes
{
    public class ListaModelosExcelDto
    {
            public string Id { get; set; }
            public string Modelo { get; set; }
            public string Marca_Id { get; set; }
            public string Marca { get; set; }
    }
}
