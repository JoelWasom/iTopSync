﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class PcDto
    {
        public long Id { get; set; }
        public string Tipo { get; set; }
        public string Descripcion { get; set; }
    }
}
