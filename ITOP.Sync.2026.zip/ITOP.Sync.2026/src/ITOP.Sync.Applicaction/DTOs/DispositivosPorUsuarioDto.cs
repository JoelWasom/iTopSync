﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class DispositivosPorUsuarioDto
    {
        public string Usuario { get; set; } = string.Empty;
        public List<string> Seriales { get; set; } = new();

    }
}
