﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.DTOs
{
    public class TypologyDto
    {
        public long Id { get; set; }
        public string Nombre { get; set; }
        public string Clase { get; set; }
    }
}
