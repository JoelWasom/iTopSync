﻿using System.Text.Json.Serialization;

namespace ITOP.Sync.Applicaction.Models
{
    public class ItopObject<T>
    {
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; }

        [JsonPropertyName("class")]
        public string Class { get; set; }

        [JsonPropertyName("key")]
        public string Key { get; set; }

        [JsonPropertyName("fields")]
        public T Fields { get; set; }
    }
}