﻿using ITOP.Sync.Applicaction.DTOs;

namespace ITOP.Sync.Applicaction.Models
{
    public class SyncCache
    {
        public Dictionary<string, ModeloDto> Modelos { get; set; } = new();
        public Dictionary<string, DispositivoFisicoDto> DispositivosPorId { get; set; } = new();
        public Dictionary<string, DispositivoFisicoDto> DispositivosPorSerial { get; set; } = new();
        public Dictionary<string, ContactoDto> Contactos { get; set; } = new();
        public Dictionary<int, LocalizacionDto> Localizaciones { get; set; } = new();
        public Dictionary<int, PcDto> PCs { get; set; } = new();
        public Dictionary<string, PerifericoDto> Perifericos { get; set; } = new();
        public Dictionary<string, PersonaDto> Personas { get; set; } = new();
    }
}
