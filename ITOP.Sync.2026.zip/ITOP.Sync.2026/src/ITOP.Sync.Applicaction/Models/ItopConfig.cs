﻿
namespace ITOP.Sync.Applicaction.Models
{
    public class ItopConfig
    {
        public const string SecctionName = "ItopApi";
        public string BaseUrl { get; set; } = string.Empty;
        public string User { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
