﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Models
{
    public class UsuarioADInfo
    {
        public string Usuario { get; set; } = string.Empty;
        public string NombreCompleto { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public bool Existe { get; set; }
        public bool Habilitado { get; set; }
        public bool Bloqueado { get; set; }
        public DateTime? FechaExpiracion { get; set; }
    }
}
