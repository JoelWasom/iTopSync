﻿using System.Text.Json.Serialization;

namespace ITOP.Sync.Applicaction.Models
{
    public class ItopResponse<T>
    {
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; }

        [JsonPropertyName("objects")]
        public Dictionary<string, ItopObject<T>> Objects { get; set; } = [];
    }
}
