﻿
namespace ITOP.Sync.Applicaction.Models
{
    internal class ItopRequest
    {
        public string Operation { get; set; }

        public string Class { get; set; }

        public string Key { get; set; }

        public string OutputFields { get; set; }

        public string Comment { get; set; }

        public object Fields { get; set; }
    }
}
