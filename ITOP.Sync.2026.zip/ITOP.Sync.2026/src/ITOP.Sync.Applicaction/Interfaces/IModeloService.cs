﻿
using ITOP.Sync.Applicaction.DTOs;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IModeloService
    {
        Task<List<ModeloDto>> GetModelosAsync();
    }
}
