﻿
using ITOP.Sync.Applicaction.DTOs;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IExcelReaderService
    {
        Task<List<ExcelConsolidadoDto>> LeerArchivo(string ruta);
        Task<List<DispositivosPorUsuarioDto>> AgruparDatosExcel(List<ExcelConsolidadoDto> data);
    }
}
