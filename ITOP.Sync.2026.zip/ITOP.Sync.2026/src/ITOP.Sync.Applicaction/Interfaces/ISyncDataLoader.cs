﻿
using ITOP.Sync.Applicaction.Models;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface ISyncDataLoader
    {
        Task<SyncCache> LoadAsync();
    }
}
