﻿using ITOP.Sync.Applicaction.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IDispositivoFisicoService
    {
        Task<List<DispositivoFisicoDto>> GetDispositivosByContactAsync(string cuenta);
        Task<List<DispositivoFisicoDto>> GetDispositivosByStatusAsync(string estado);
        Task<List<DispositivoFisicoDto>> GetDispositivosAsync(string clase);
        Task<bool> UpdateDispositivoStatusAsync();
    }
}
