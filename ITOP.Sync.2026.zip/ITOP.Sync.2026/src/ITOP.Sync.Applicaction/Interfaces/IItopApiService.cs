﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IItopApiService
    {
        Task<string> ExecuteAsync(object request);
        Task<string> TestConnectionAsync();
        Task<List<T>> GetAsync<T>(string className,string oql,string outputFields = "*");
        Task<bool> UpdateAsync<T>(string className, string key, object fields, string comment = "");
    }
}
