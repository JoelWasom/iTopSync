﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface ILoggerService
    {
        void LogInformation(string message);
        void LogWarning(string message);
        void LogError(string message);
        void LogError(Exception exception, string message);
    }
}
