﻿
using ITOP.Sync.Applicaction.DTOs;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IPersonaService
    {
        Task<List<PersonaDto>> GetPersonasAsync();
        Task<List<ContactoDto>> GetContactoAsync();
    }
}
