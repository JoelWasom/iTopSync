﻿using ITOP.Sync.Applicaction.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IActiveDirectoryService
    {
        bool ActiveDirectoryDisponible();
        UsuarioADInfo ObtenerInformacionUsuario(string usuario);
    }
}
