﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.DTOs.Reportes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IExcelWriterService
    {
        void GenerarListaModelosEnExcel(string ruta, List<ModeloDto> data);
        void GenerarListaPersonasEnExcel(string ruta, List<PersonaDto> data, List<ContactoDto> data2);
        void GenerarListaDispositivosEnExcel(string ruta, List<DispositivoFisicoDto> data);
    }
}
