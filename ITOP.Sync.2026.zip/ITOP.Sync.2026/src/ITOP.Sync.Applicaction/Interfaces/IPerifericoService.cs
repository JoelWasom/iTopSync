﻿using ITOP.Sync.Applicaction.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Applicaction.Interfaces
{
    public interface IPerifericoService
    {
        Task<List<PerifericoDto>> GetPerifericosAsync();
    }
}
