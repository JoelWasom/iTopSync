﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Infrastructure.Services
{
    public class DispositivoFisicoService : IDispositivoFisicoService
    {
        private readonly IItopApiService _client;
        public DispositivoFisicoService(IItopApiService client)
        {
            _client = client;
        }
        public async Task<List<DispositivoFisicoDto>> GetDispositivosByContactAsync(string cuenta)
        {
            var Clase = "PhysicalDevice";
            var OQL = "SELECT PhysicalDevice AS d " +
                "JOIN Person AS p ON d.pdasigned_id=p.id " +
                "JOIN User AS u ON u.contactid=p.id " +
                $"WHERE u.login = '{cuenta}'";
            string Campos = "*";
            return await _client.GetAsync<DispositivoFisicoDto>(Clase, OQL, Campos);
        }
        public async Task<List<DispositivoFisicoDto>> GetDispositivosByStatusAsync(string cuenta)
        {
            var Clase = "PhysicalDevice";
            var OQL = "SELECT PhysicalDevice";
            string Campos = "id,name,type,brand_id,brand_name";
            return await _client.GetAsync<DispositivoFisicoDto>(Clase, OQL, Campos);
        }
        public async Task<List<DispositivoFisicoDto>> GetDispositivosAsync(string clase)
        {
            return await _client.GetAsync<DispositivoFisicoDto>(clase, $"SELECT {clase}", "*");
        }
        public async Task<bool> UpdateDispositivoStatusAsync()
        {
            var campos = new
            {
                pertype = "Memoria"
            };

            var result = await _client.UpdateAsync<DispositivoFisicoDto>(
                className: "Peripheral",
                key: "2344",
                fields: campos,
                comment: "Regularización masiva desde ITOP.Sync.2026"
            );
            return result;
        }
    }
}
