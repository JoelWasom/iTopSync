﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;

namespace ITOP.Sync.Infrastructure.Services
{
    public class PersonaService: IPersonaService
    {
        private readonly IItopApiService _client;
        public PersonaService(IItopApiService client)
        {
            _client = client;
        }
        public async Task<List<PersonaDto>> GetPersonasAsync()
        {
            var Clase = "User";
            var OQL = "SELECT User ";
            string Campos = "contactid,first_name,last_name,email,login";

            return await _client.GetAsync<PersonaDto>(Clase, OQL, Campos);
        }
        public async Task<List<ContactoDto>> GetContactoAsync()
        {
            var Clase = "Contact";
            var OQL = "SELECT Contact ";
            string Campos = "id,status,function";

            return await _client.GetAsync<ContactoDto>(Clase, OQL, Campos);
        }
    }
}
