﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;
using ITOP.Sync.Applicaction.Models;

namespace ITOP.Sync.Infrastructure.Services
{
    public class SyncDataLoader : ISyncDataLoader
    {
        private readonly IModeloService _modeloService;
        private readonly IDispositivoFisicoService _dispositivoFisicoService;
        private readonly IPerifericoService _perifericoService;
        private readonly IPersonaService _personaService;

        public SyncDataLoader(
            IDispositivoFisicoService dispositivoService,
            IModeloService modeloService,
            IPerifericoService perifericoService,
            IPersonaService personaService)
        {
            _dispositivoFisicoService = dispositivoService;
            _modeloService = modeloService;
            _perifericoService = perifericoService;
            _personaService = personaService;
        }

        public async Task<SyncCache> LoadAsync()
        {
            var cache = new SyncCache();
            /************      MODELOS         ***********/
            var modelos = await _modeloService.GetModelosAsync();
            cache.Modelos = modelos.ToDictionary(x => x.Id);

            /************      DISPOSITIVOS         ***********/
            var dispositivos = new List<DispositivoFisicoDto>();
            dispositivos.AddRange(await _dispositivoFisicoService.GetDispositivosAsync("Tablet"));
            dispositivos.AddRange(await _dispositivoFisicoService.GetDispositivosAsync("PC"));
            dispositivos.AddRange(await _dispositivoFisicoService.GetDispositivosAsync("Peripheral"));
            dispositivos.AddRange(await _dispositivoFisicoService.GetDispositivosAsync("Printer"));
            dispositivos.AddRange(await _dispositivoFisicoService.GetDispositivosAsync("MobilePhone"));
            cache.DispositivosPorId = dispositivos.Where(x => !string.IsNullOrWhiteSpace(x.Id)).ToDictionary(x => x.Id);
            cache.DispositivosPorSerial = dispositivos.Where(x => !string.IsNullOrWhiteSpace(x.NumeroSerial)
                                            && x.NumeroSerial !="S/N" 
                                            && x.NumeroSerial != "SN"
                                            && x.NumeroSerial != "--"
                                            && x.NumeroSerial != "-"
                ).GroupBy(x=>x.NumeroSerial).ToDictionary(g =>g.Key, g=>g.OrderBy(x=>x.Estado!= "No Disponible").First());

            /************      PERIFERICOS         ***********/
            var perifericos = await _perifericoService.GetPerifericosAsync();
            cache.Perifericos = perifericos.Where(x => !string.IsNullOrWhiteSpace(x.Id)).ToDictionary(x=>x.Id);

            /************      PERSONAS y CONTACTO         ***********/
            var personas = await _personaService.GetPersonasAsync();
            cache.Personas = personas.Where(x => !string.IsNullOrWhiteSpace(x.Id)).GroupBy(x => x.Id).ToDictionary(g => g.Key,g => g.First());

            var contactos = await _personaService.GetContactoAsync();
            cache.Contactos = contactos.Where(x => !string.IsNullOrWhiteSpace(x.Id)).GroupBy(x => x.Id).ToDictionary(g => g.Key, g => g.First());

            return cache;
        }
    }
}
