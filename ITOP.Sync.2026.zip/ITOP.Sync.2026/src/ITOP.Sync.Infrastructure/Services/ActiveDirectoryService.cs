﻿using ITOP.Sync.Applicaction.Interfaces;
using ITOP.Sync.Applicaction.Models;
using System.DirectoryServices.AccountManagement;

namespace ITOP.Sync.Infrastructure.Services;
public class ActiveDirectoryService : IActiveDirectoryService
{
    private readonly string _dominio;

    public ActiveDirectoryService(string dominio)
    {
        _dominio = dominio;
    }
    public bool ActiveDirectoryDisponible()
    {
        try
        {
            using var context = new PrincipalContext(
                ContextType.Domain,
                _dominio);

            return context.ConnectedServer is not null;
        }
        catch (PrincipalServerDownException)
        {
            return false;
        }
        catch (PrincipalOperationException)
        {
            return false;
        }
    }
    public UsuarioADInfo ObtenerInformacionUsuario(string usuario)
    {
        var resultado = new UsuarioADInfo
        {
            Usuario = usuario,
            Existe = false
        };
        try
        {
            using var context = new PrincipalContext(ContextType.Domain,_dominio);

            var user = UserPrincipal.FindByIdentity(
                context,
                IdentityType.SamAccountName,
                usuario);

            if (user == null)
                return resultado;

            resultado.Existe = true;
            resultado.NombreCompleto = user.DisplayName ?? string.Empty;
            return resultado;
        }
        catch (Exception ex)
        {
            throw new Exception(
                $"Error al consultar Active Directory para el usuario '{usuario}'",
                ex);
        }
    }
}