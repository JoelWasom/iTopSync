﻿using ClosedXML.Excel;
using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;

namespace ITOP.Sync.Infrastructure.Services
{
    public class ExcelReaderService : IExcelReaderService
    {
        public async Task<List<ExcelConsolidadoDto>> LeerArchivo(string ruta)
        {
            var resultado = new List<ExcelConsolidadoDto>();

            using var workbook = new XLWorkbook(ruta);

            var ws = workbook.Worksheet(1);

            var rows = ws.RowsUsed().Skip(1);

            foreach (var row in rows)
            {
                resultado.Add(new ExcelConsolidadoDto
                {
                    Usuario = row.Cell(3).GetValue<string>(),
                    Nombre = row.Cell(2).GetValue<string>(),
                    Correo = row.Cell(3).GetValue<string>(),
                    TipoProducto = row.Cell(5).GetValue<string>(),
                    Cantidad = row.Cell(6).GetValue<int>(),
                    Marca = row.Cell(7).GetValue<string>(),
                    Modelo = row.Cell(8).GetValue<string>(),
                    Descripcion = row.Cell(9).GetValue<string>(),
                    Serial = row.Cell(11).GetValue<string>(),
                    Codigo = row.Cell(13).GetValue<string>(),
                    Clase = row.Cell(15).GetValue<string>(),
                    Observacion = row.Cell(16).GetValue<string>(),
                });
            }
            return resultado;
        }
        public async Task <List<DispositivosPorUsuarioDto>> AgruparDatosExcel(List<ExcelConsolidadoDto> data)
        {
            var itemsPorUsuario = data
                   .Where(x => !string.IsNullOrWhiteSpace(x.Serial))
                   .GroupBy(x => x.Usuario)
                   .Select(g => new DispositivosPorUsuarioDto
                   {
                       Usuario = g.Key,
                       Seriales = g
                           .Select(x => x.Serial)
                           .Distinct()
                           .ToList()
                   }).ToList();
            return itemsPorUsuario;
        }
    }
}