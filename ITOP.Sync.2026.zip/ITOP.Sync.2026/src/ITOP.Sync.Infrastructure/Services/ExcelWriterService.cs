﻿using ClosedXML.Excel;
using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;

namespace ITOP.Sync.Infrastructure.Services
{
    public class ExcelWriterService : IExcelWriterService
    {
        public void GenerarListaModelosEnExcel(string ruta, List<ModeloDto> data)
        {
            using var workbook = new XLWorkbook(ruta);

            var ws = workbook.Worksheet("Modelos");

            ws.Clear();
            // Encabezados
            ws.Cell(1, 1).Value = "Id";
            ws.Cell(1, 2).Value = "Modelo";
            ws.Cell(1, 3).Value = "Tipo";
            ws.Cell(1, 4).Value = "Marca_Id";
            ws.Cell(1, 5).Value = "Marca";

            int fila = 2;

            foreach (var modelo in data)
            {
                ws.Cell(fila, 1).Value = modelo.Id;
                ws.Cell(fila, 2).Value = modelo.Nombre;
                ws.Cell(fila, 3).Value = modelo.Tipo;
                ws.Cell(fila, 4).Value = modelo.MarcaId;
                ws.Cell(fila, 5).Value = modelo.Marca;

                fila++;
            }
            // Ajustar ancho de columnas
            ws.Columns().AdjustToContents();
            workbook.Save();
        }
        public void GenerarListaPersonasEnExcel(string ruta, List<PersonaDto> data,List<ContactoDto> data2)
        {
            using var workbook = new XLWorkbook(ruta);

            var ws = workbook.Worksheet("dataPersonas");

            // Conserva formato y elimina únicamente contenido
            ws.CellsUsed().Clear(XLClearOptions.Contents);

            // Encabezados
            ws.Cell(1, 1).Value = "Id";
            ws.Cell(1, 2).Value = "Nombres";
            ws.Cell(1, 3).Value = "Usuario";
            ws.Cell(1, 4).Value = "Email";
            ws.Cell(1, 5).Value = "Cargo";

            int fila = 2;

            var contactosDict = data2
                .Where(x => !string.IsNullOrWhiteSpace(x.Id))
                .GroupBy(x => x.Id)
                .ToDictionary(g => g.Key, g => g.First());

            foreach (var obj in data)
            {
                try
                {
                    if (obj == null)
                        continue;

                    contactosDict.TryGetValue(obj.Id ?? string.Empty, out var contacto);

                    ws.Cell(fila, 1).Value = obj.Id ?? "";
                    ws.Cell(fila, 2).Value =
                        $"{obj.Nombres} {obj.Apellidos}".Trim().ToUpper();

                    ws.Cell(fila, 3).Value = obj.Usuario ?? "";
                    ws.Cell(fila, 4).Value = obj.Email ?? "";
                    ws.Cell(fila, 5).Value =
                        (contacto?.Cargo ?? "").ToUpper();

                    fila++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(
                        $"Error en fila {fila}, Id={obj?.Id}, Usuario={obj?.Usuario}");

                    Console.WriteLine(ex.ToString());

                    // Continúa con el siguiente registro
                    continue;
                }
            }

            ws.Columns().AdjustToContents();
            workbook.Save();
        }
        public void GenerarListaDispositivosEnExcel(string ruta, List<DispositivoFisicoDto> data)
        {
            using var workbook = new XLWorkbook(ruta);

            var ws = workbook.Worksheet("dataDispositivos");

            ws.Clear();
            // Encabezados
            ws.Cell(1, 1).Value = "Id";
            ws.Cell(1, 2).Value = "NumeroSerie";
            ws.Cell(1, 3).Value = "Clase";
            ws.Cell(1, 4).Value = "ModeloId";
            ws.Cell(1, 5).Value = "Modelo";
            ws.Cell(1, 6).Value = "MarcaId";
            ws.Cell(1, 7).Value = "Marca";

            int fila = 2;

            foreach (var modelo in data)
            {
                ws.Cell(fila, 1).Value = modelo.Id;
                ws.Cell(fila, 2).Value = modelo.NumeroSerial;
                ws.Cell(fila, 3).Value = modelo.Clase;
                ws.Cell(fila, 4).Value = modelo.ModeloId;
                ws.Cell(fila, 5).Value = modelo.Modelo;
                ws.Cell(fila, 6).Value = modelo.MarcaId;
                ws.Cell(fila, 7).Value = modelo.Marca;

                fila++;
            }
            // Ajustar ancho de columnas
            ws.Columns().AdjustToContents();
            workbook.Save();
        }
    }
}