﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOP.Sync.Infrastructure.Services
{
    public class PerifericoService : IPerifericoService
    {
        private readonly IItopApiService _client;
        public PerifericoService(IItopApiService client)
        {
            _client = client;
        }
        public async Task<List<PerifericoDto>> GetPerifericosAsync()
        {
            var Clase = "Peripheral";
            var OQL = "SELECT Peripheral WHERE id=2344";
            string Campos = "*";
            return await _client.GetAsync<PerifericoDto>(Clase, OQL, Campos);
        }

    }
}
