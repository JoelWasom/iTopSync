﻿using ITOP.Sync.Applicaction.DTOs;
using ITOP.Sync.Applicaction.Interfaces;

namespace ITOP.Sync.Infrastructure.Services
{
    public class ModeloService : IModeloService
    {
        private readonly IItopApiService _client;
        public ModeloService(IItopApiService client)
        {
            _client = client;
        }
        public async Task<List<ModeloDto>> GetModelosAsync()
        {
            var Clase = "Model";
            var OQL = "SELECT Model";
            string Campos = "id,name,type,brand_id,brand_name";
            return await _client.GetAsync<ModeloDto>(Clase, OQL,Campos);
        }
    }
}
