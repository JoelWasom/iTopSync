﻿using ITOP.Sync.Applicaction.Interfaces;
using ITOP.Sync.Applicaction.Models;
using Microsoft.Extensions.Options;
using System.Diagnostics;
using System.Text.Json;

namespace ITOP.Sync.Infrastructure.Services
{
    public class ItopApiService : IItopApiService
    {
        private readonly HttpClient _httpClient;
        private readonly ItopConfig _config;
        private readonly ILoggerService _logger;
        public ItopApiService(HttpClient httpClient, IOptions<ItopConfig> options, ILoggerService logger)
        {
            _httpClient = httpClient;
            _config = options.Value;
            _logger = logger;
        }
        public async Task<string> ExecuteAsync(object request)
        {
            var jsonData = JsonSerializer.Serialize(request);
            var formData = new FormUrlEncodedContent(
                [
                    new KeyValuePair<string,string>("auth_user", _config.User),
                    new KeyValuePair<string,string>("auth_pwd",_config.Password),
                    new KeyValuePair<string,string>("json_data",jsonData)
                ]);
            var response = await _httpClient.PostAsync(_config.BaseUrl, formData);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }
        public async Task<string> TestConnectionAsync()
        {
            var request = new
            {
                operation = "core/get",
                @class = "Contact",
                key = "SELECT Contact",
                output_fields = "*"
            };
            return await ExecuteAsync(request);
        }
        public async Task<List<T>> GetAsync<T>(string className, string oql, string outputFields = "*")
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                _logger.LogInformation($"Iniciando consulta iTop. Clase: {className}, OQL: {oql}");
                var request = new
                {
                    operation = "core/get",
                    @class = className,
                    key = oql,
                    output_fields = outputFields
                };

                var jsonRequest = JsonSerializer.Serialize(request);

                var content = new FormUrlEncodedContent(
                [
                    new("auth_user", _config.User),
                new("auth_pwd", _config.Password),
                new("json_data", jsonRequest)
                ]);


                var response = await _httpClient.PostAsync(_config.BaseUrl, content);
                response.EnsureSuccessStatusCode();
                var jsonResponse = await response.Content.ReadAsStringAsync();
                stopwatch.Stop();
                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error HTTP al consultar iTop. Clase: {className}, StatusCode: {(int)response.StatusCode}, Response: {jsonResponse}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                    response.EnsureSuccessStatusCode();
                }
                var result = JsonSerializer.Deserialize<ItopResponse<T>>(
                    jsonResponse,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                );
                if (result == null)
                {
                    throw new Exception("No se pudo deserializar la respuesta.");
                }

                if (result.Code != 0)
                {
                    _logger.LogError($"Error iTop: {result.Message}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                    throw new Exception(result.Message);
                }
                if (result?.Objects is null)
                {
                    _logger.LogWarning($"La respuesta de iTop no contiene objetos. Clase: {className}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                    return [];
                }
                var data = result.Objects.Values
                .Where(x => x.Fields is not null)
                .Select(x => x.Fields)
                .ToList();
                _logger.LogInformation($"Consulta iTop exitosa. Clase: {className}, Registros obtenidos: {data.Count}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms" );

                return data;
            }
            catch (HttpRequestException ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"Error de comunicación HTTP con iTop. Clase: {className}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                throw;
            }
            catch (JsonException ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"Error al deserializar la respuesta de iTop. Clase: {className}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"Timeout o cancelación durante la consulta a iTop. Clase: {className}, Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                throw;
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, $"Error inesperado al consultar iTop. Clase: {className},Tiempo transcurrido: {stopwatch.ElapsedMilliseconds} ms");
                throw;
            }
        }
        public async Task<bool> UpdateAsync<T>(
            string className,
            string key,
            object fields,
            string comment = "")
        {
            try
            {
                _logger.LogInformation($"Actualizando iTop. Clase: {className}, Key: {key}");

                var request = new
                {
                    operation = "core/update",
                    @class = className,
                    key = key,
                    comment = comment,
                    fields = fields
                };
                var jsonRequest = JsonSerializer.Serialize(request);
                var content = new FormUrlEncodedContent(
                [
                    new("auth_user", _config.User),
                    new("auth_pwd", _config.Password),
                    new("json_data", jsonRequest)
                ]);

                var response = await _httpClient.PostAsync(_config.BaseUrl, content);

                var jsonResponse = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        $"Error HTTP al actualizar iTop. " +
                        $"StatusCode: {(int)response.StatusCode}, Response: {jsonResponse}");

                    response.EnsureSuccessStatusCode();
                }

                var result = JsonSerializer.Deserialize<ItopResponse<T>>(
                    jsonResponse,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                if (result == null)
                    throw new Exception("No se pudo deserializar la respuesta.");

                if (result.Code != 0)
                {
                    _logger.LogError($"Error iTop: {result.Message}");
                    throw new Exception(result.Message);
                }

                var updatedObject = result.Objects;

                _logger.LogInformation($"Actualización exitosa. Clase: {className}, Key: {key}");

                
                return result.Code==0;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"Error HTTP al actualizar iTop. Clase: {className}");
                throw;
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, $"Error al deserializar respuesta iTop. Clase: {className}");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, $"Timeout o cancelación durante la integración con iTop. Clase: {className}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error inesperado al integrarse con iTop. Clase: {className}");
                throw;
            }
        }
        public async Task<string> CreateAsync<T>(
            string className,
            object fields,
            string comment = "")
        {
            try
            {
                _logger.LogInformation($"Creando registro en iTop. Clase: {className}");

                var request = new
                {
                    operation = "core/create",
                    @class = className,
                    comment = comment,
                    fields = fields
                };

                var jsonRequest = JsonSerializer.Serialize(request);

                var content = new FormUrlEncodedContent(
                [
                    new("auth_user", _config.User),
                    new("auth_pwd", _config.Password),
                    new("json_data", jsonRequest)
                ]);

                var response = await _httpClient.PostAsync(_config.BaseUrl, content);

                var jsonResponse = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        $"Error HTTP al crear en iTop. " +
                        $"StatusCode: {(int)response.StatusCode}, " +
                        $"Response: {jsonResponse}");

                    response.EnsureSuccessStatusCode();
                }

                var result = JsonSerializer.Deserialize<ItopResponse<T>>(
                    jsonResponse,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                if (result == null)
                    throw new Exception("No se pudo deserializar la respuesta.");

                if (result.Code != 0)
                {
                    _logger.LogError($"Error iTop: {result.Message}");
                    throw new Exception(result.Message);
                }

                var createdObject = result.Objects?.Values.FirstOrDefault();

                if (createdObject == null)
                    throw new Exception("No se recibió el objeto creado.");

                _logger.LogInformation($"Creación exitosa. Clase: {className}, Key: {createdObject.Key}");

                return createdObject.Key;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"Error HTTP al crear registro. Clase: {className}");
                throw;
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, $"Error al deserializar respuesta iTop. Clase: {className}");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, $"Timeout durante la integración con iTop. Clase: {className}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error inesperado al crear registro. Clase: {className}");
                throw;
            }
        }
    }
}