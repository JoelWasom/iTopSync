﻿using ITOP.Sync.Applicaction.Interfaces;
using Microsoft.Extensions.Configuration;

namespace ITOP.Sync.Infrastructure.Logging
{
    public class LoggerService: ILoggerService
    {
        private readonly string _logPath;
        private readonly object _lock = new object();
        public LoggerService(IConfiguration configuration)
        {
            //var logFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");

            var logFolder = configuration["LogSettings:Folder"] ?? "Logs";
            var fileNamePrefix = configuration["LogSettings:FileNamePrefix"] ?? "ITOP_SYNC_";

            // Si la ruta es relativa, utiliza el directorio de la aplicación
            if (!Path.IsPathRooted(logFolder))
            {
                logFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, logFolder);
            }

            if (!Directory.Exists(logFolder))
                Directory.CreateDirectory(logFolder);

            _logPath = Path.Combine(logFolder, $"{fileNamePrefix}{DateTime.Now:yyyyMMdd}.log");
        }

        public void LogInformation(string message)
            => WriteLog("INFO", message);

        public void LogWarning(string message)
            => WriteLog("WARN", message);

        public void LogError(string message)
            => WriteLog("ERROR", message);

        public void LogError(Exception ex, string message)
            => WriteLog("ERROR", $"{message} | {ex}");

        private void WriteLog(string level, string message)
        {
            var line =
                $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] {message}";
            lock (_lock) 
            {
                File.AppendAllText(_logPath, line + Environment.NewLine);
            }
        }
    }
}